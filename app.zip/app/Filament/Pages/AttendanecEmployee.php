<?php

namespace App\Filament\Pages;

use Filament\Schemas\Schema;
use Exception;
use DateTime;
use App\Forms\Components\KeyPadTest;
use App\Models\Attendance;
use App\Models\Employee;
use App\Models\Setting;
use App\Notifications\NotificationAttendance;
use Carbon\Carbon;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Notifications\Notification;
use Filament\Pages\BasePage;
use Filament\Support\Enums\Alignment;
use Filament\Support\Enums\IconPosition;
use Filament\Support\Enums\IconSize;

class AttendanecEmployee extends BasePage
// implements HasForms

{
    use InteractsWithForms;
    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected string $view = 'filament.pages.attendanec-employee';
    private $date = '';
    // private $date ;
    private $time = '';
    // private $time ;

    public ?array $data = [];
    public function hasLogo(): bool
    {
        return true;
    }

    public static function alignFormActionsStart(): void
    {
        static::$formActionsAlignment = Alignment::Start;
    }

    public static function alignFormActionsCenter(): void
    {
        static::$formActionsAlignment = Alignment::Center;
    }

    public static function alignFormActionsEnd(): void
    {
        static::$formActionsAlignment = Alignment::End;
    }

    public string $rfid = ''; // Bind this to the input

    public function appendToDisplay(string $value)
    {
        // Only append if input length is acceptable, reducing unnecessary operations
        if (strlen($this->rfid) < 10) {
            $this->rfid .= $value; // Append the value to the RFID input
        }
    }

    public function clearDisplay()
    {
        $this->rfid = ''; // Clear the RFID input
    }

    public function form(Schema $schema): Schema
    {

        app()->setLocale('en');
        return $schema
            ->components([

                DateTimePicker::make('date_time')
                    ->label('التاريخ والوقت')
                // ->timezone('Asia/Kuala_Lumpur')
                    ->prefixIcon('heroicon-o-clock')
                    ->prefixIconColor('success')
                // ->required()
                    ->seconds(false)
                    ->hidden(function () {
                        return isSuperAdmin() ? false : true;
                    })
                ,
                KeyPadTest::make('rfid')->default($this->rfid),
                // TextInput::make('rfid')
                //     ->autocomplete(false)
                //     ->label('Employee RFID')
                //     ->prefixIcon('heroicon-m-identification')
                //     ->prefixIconColor('success')
                //     ->label('قم بإدخال رقم التحضير  الخاص بك واضغط على زر البصمة')
                //     ->required()
                //     ->placeholder('RFID')
                //     ->maxLength(255),
            ])->statePath('data');
    }

    public function submit()
    {

        // Only handle submission if input is valid
        $formData = $this->form->getState();

        $rfid = $this->rfid;
        $formData['rfid'] = $rfid;

        $this->clearDisplay();
        $handle = $this->handleEmployeePeriodData($formData);
        if (isset($handle['success']) && !$handle['success']) {
            return $this->sendWarningNotification($handle['message']);
        }
    }

    public function handleEmployeePeriodData($data)
    {
        $dateTime = now();

        if (isSuperAdmin()) {
            $dateTime = $data['date_time'];
        }

        // Create a Carbon instance
        $carbonDateTime = Carbon::parse($dateTime);

        // Get the date and time separately
        $date = $carbonDateTime->toDateString(); // Output: 2024-10-01
        $time = $carbonDateTime->toTimeString();

        $rfid = $data['rfid'];
        $employee = Employee::where('rfid', $rfid)->first();
        $employeePeriods = $employee?->periods;

        if (!is_null($employee) && count($employeePeriods) > 0) {
            $day = Carbon::parse($date)->format('l');

            // Decode the days array for each period
            $workTimePeriods = $employee->periods->map(function ($period) {
                $period->days = json_decode($period->days); // Ensure days are decoded
                return $period;
            });

            // Filter periods by the day
            $periodsForDay = $workTimePeriods->filter(function ($period) use ($day) {
                return in_array($day, $period->days);
            });

            // Check if no periods are found for the given day
            if ($periodsForDay->isEmpty()) {
                return
                    [
                    'success' => false,
                    'message' => __('notifications.you_dont_have_periods_today') . ' (' . $day . ')',
                ]
                ;
            }
            $this->handleAttendance($employee, $time, $date, $day, $periodsForDay);

        } elseif (!is_null($employee) && count($employeePeriods) == 0) {

            return
                [
                'success' => false,
                'message' => __('notifications.sorry_no_working_hours_have_been_added_to_you_please_contact_the_administration'),
            ]
            ;
        } else {
            return
                [
                'success' => false,
                'message' => __('notifications.there_is_no_employee_at_this_number') . $data['rfid'],
            ]
            ;

        }
    }
    public function findClosestPeriod($time, $periods)
    {
        // تحويل $time إلى كائن وقت
        $current_time = strtotime($time);

        // متغير لحفظ أقل فرق زمني والفترة الأقرب
        $min_difference = null;
        $closest_period = null;

        foreach ($periods as $period) {
            // تحويل وقتي البداية والنهاية إلى كائنات وقت
            $period_start = strtotime($period['start_at']);
            $period_end = strtotime($period['end_at']);

            // حساب الفرق بين الوقت الحالي ووقت البداية
            $difference_from_start = abs($current_time - $period_start);
            // حساب الفرق بين الوقت الحالي ووقت النهاية
            $difference_from_end = abs($current_time - $period_end);

            // استخدام الفرق الأصغر بين البداية والنهاية
            $closest_difference = min($difference_from_start, $difference_from_end);

            // تحديث الفترة الأقرب إذا كان الفرق أصغر من الفرق السابق
            if (is_null($min_difference) || $closest_difference < $min_difference) {
                $min_difference = $closest_difference;
                $closest_period = $period;
            }
        }
        return $closest_period;
    }

    public function handleAttendance($employee, $time, $date, $day, $periodsForDay)
    {
        $closestPeriod = $this->findClosestPeriod($time, $periodsForDay);

        if (!$closestPeriod) {
            // No period found, so we return with an error or handle accordingly
            return $this->sendWarningNotification(__('notifications.no_valid_period_found_for_the_specified_time') . $time);
        }

        // Check if attendance exists for this period, date, and day
        $existAttendance = $this->getExistingAttendance($employee, $closestPeriod, $date, $day, $time);

        if (isset($existAttendance['in_previous'])) {
            if ($existAttendance['in_previous']['check_type'] == Attendance::CHECKTYPE_CHECKIN) {
                return $this->createAttendance($employee, $closestPeriod, $date, $time, $day, Attendance::CHECKTYPE_CHECKOUT, $existAttendance);
            } else {

                $endTime = Carbon::parse($closestPeriod->end_at);
                $checkTime = Carbon::parse($time);

                if ($endTime->gt($checkTime)) {
                    // $date = $existAttendance['in_previous']?->check_date;
                    // $day = $existAttendance['previous_day_name'];

                    return $this->createAttendance($employee, $closestPeriod, $date, $time, $day, Attendance::CHECKTYPE_CHECKIN, $existAttendance);
                } else {
                    return $this->sendWarningNotification(__('notifications.attendance_time_is_greater_than_current_period_end_time') . ':(' . $closestPeriod?->name . ')');

                }
            }
        }

        // Determine the action based on attendance count
        $attendanceCount = $existAttendance->count();
        if ($attendanceCount === 0) {
            $checkType = Attendance::CHECKTYPE_CHECKIN;
        } elseif ($attendanceCount > 0) {
            // تحقق مما إذا كان العدد زوجي أو فردي
            if ($attendanceCount % 2 === 0) {
                $checkType = Attendance::CHECKTYPE_CHECKIN;
            } else {
                $checkType = Attendance::CHECKTYPE_CHECKOUT;
            }
        }

        return $this->createAttendance($employee, $closestPeriod, $date, $time, $day, $checkType);

    }

    public function createAttendance($employee, $nearestPeriod, $date, $checkTime, $day, $checkType, $previousRecord = null)
    {
        $checkTimeStr = $checkTime;
        // Ensure that $checkTime is a Carbon instance
        $checkTime = Carbon::parse($checkTime);

        // Check if the user has created a record within the last minute

        $lastRecord = Attendance::where('created_at', '>=', Carbon::now()->subMinutes(15))->where('employee_id', $employee->id)->first();

        if ($lastRecord) {
            // // Calculate the remaining seconds until a new record can be created
            $remainingSeconds = Carbon::parse($lastRecord->created_at)->addMinutes(15)->diffInSeconds(Carbon::now());

            // Convert seconds to minutes and seconds
            $remainingMinutes = floor($remainingSeconds / 60);
            $remainingSeconds = $remainingSeconds % 60;
            $remainingMinutes *= -1;
            $remainingSeconds *= -1;

            return $this->sendWarningNotification(__('notifications.please_wait_for_a') . ' ' . $remainingMinutes . ' ' . __('notifications.minutue') . ' ' . $remainingSeconds . ' ' . __('notifications.second'));

        }
        // Prepare attendance data
        $attendanceData = [
            'employee_id' => $employee->id,
            'period_id' => $nearestPeriod->id,
            'check_date' => $date,
            'check_time' => $checkTime,
            'day' => $day,
            'check_type' => $checkType,
            'branch_id' => $employee?->branch?->id,
            'created_by' => 0, // Consider changing this to use the authenticated user ID if applicable
        ];

        // Handle check-in and check-out scenarios
        if ($checkType === Attendance::CHECKTYPE_CHECKIN) {

            $periodEndTime = $nearestPeriod->end_at;
            $periodStartTime = $nearestPeriod->start_at;

            $diff = $this->calculateTimeDifference($checkTime->toTimeString(), $periodStartTime, true);

            if ($checkTime->toTimeString() < $periodStartTime && $diff > Setting::getSetting('hours_count_after_period_after')) {
                return $this->sendWarningNotification(__('notifications.you_cannot_attendance_before') . ' ' . $diff . ' ' . __('notifications.hours'));
            }
            if ($periodStartTime > $periodEndTime
                && ($checkTimeStr >= '00:00:00' && $checkTimeStr < $periodEndTime) && $previousRecord == null

            ) {
                $minusDate = strtotime("$date -1 day");
                $prevDayName = date('l', $minusDate);
                $prevDate = date('Y-m-d', $minusDate);
                $attendanceData['check_date'] = $prevDate;
                $attendanceData['day'] = $prevDayName;
            }

            if ($previousRecord) {
                $attendanceData['is_from_previous_day'] = 1;
                $attendanceData['check_date'] = $previousRecord['in_previous']?->check_date;
            }

            $attendanceData = array_merge($attendanceData, $this->storeCheckIn($nearestPeriod, $checkTime, $date));
            $notificationMessage = __('notifications.the_attendance_has_been_recorded');
        } elseif ($checkType === Attendance::CHECKTYPE_CHECKOUT) {

            $periodEndTime = $nearestPeriod->end_at;
            
            if ($checkTime->toTimeString() > $periodEndTime 
            &&
             ($periodEndTime > $nearestPeriod->start_at && $periodEndTime != '12:00:00')) {
                $diff = $this->calculateTimeDifference($periodEndTime, $checkTime->toTimeString(), true);

                if ($diff >= Setting::getSetting('hours_count_after_period_after')) {
                    return $this->sendWarningNotification('Times up');
                }
            }
            $attendanceData = array_merge($attendanceData, $this->storeCheckOut($nearestPeriod, $employee->id, $date, $checkTime, $previousRecord));
            $notificationMessage = __('notifications.the_departure_has_been_recorded');
        }
        // Try to create the attendance record
        try {
            Attendance::create($attendanceData);
            // Send success notification
            return $this->sendAttendanceNotification($employee->name, $notificationMessage);
        } catch (Exception $e) {
            // Send warning notification in case of failure
            return $this->sendWarningNotification($e->getMessage());
        }
    }

    /**
     * get existing attendance
     */
    private function getExistingAttendance($employee, $closestPeriod, $date, $day, $currentCheckTime)
    {
        $attendances = Attendance::where('employee_id', $employee->id)
            ->where('period_id', $closestPeriod->id) // Using array key if closestPeriod is an array
            ->where('check_date', $date)
            ->where('day', $day)
            ->select('check_type', 'check_date')
            ->get();
        if ($attendances->count() === 0) {

            $previousDate = Carbon::parse($date)->subDay()->format('Y-m-d');
            $previousDayName = Carbon::parse($date)->subDay()->format('l');
            $attendanceInPreviousDay = Attendance::where('employee_id', $employee->id)
                ->where('period_id', $closestPeriod->id)
                ->where('check_date', $previousDate)
                ->latest('id')
                ->first();

            if ($attendanceInPreviousDay) {
                $isLatestSamePeriod = $this->checkIfSamePeriod($employee->id, $attendanceInPreviousDay, $closestPeriod, $previousDate, $date, $currentCheckTime);
                if (!$isLatestSamePeriod) {
                    return $attendances;
                }

                if (($attendanceInPreviousDay->check_type == Attendance::CHECKTYPE_CHECKIN)) {
                    return ['in_previous' => $attendanceInPreviousDay,
                        'previous_day_name' => $previousDayName,
                        'check_type' => Attendance::CHECKTYPE_CHECKOUT,
                    ];
                } else {
                    return ['in_previous' => $attendanceInPreviousDay,
                        'previous_day_name' => $previousDayName,
                        'check_type' => Attendance::CHECKTYPE_CHECKIN,
                    ];
                }
            }

            return $attendances;

        }
        return $attendances;
    }

    /**
     * to create notification
     */
    private function createNotification($checkType, $employee)
    {

    }

    /**
     * to store checkin attendance
     */
    private function storeCheckIn($nearestPeriod, $checkTime, $date)
    {

        $allowedTimeBeforePeriod = Carbon::createFromFormat('H:i:s', $nearestPeriod->start_at)->subHours((int) Setting::getSetting('hours_count_after_period_before'))->format('H:i:s');

        $allowedLateMinutes = $nearestPeriod?->allowed_count_minutes_late;
        $startTime = Carbon::parse($nearestPeriod->start_at);

        if ($checkTime->gt($startTime) && $nearestPeriod?->start_at) {
            // Employee is late
            $data['delay_minutes'] = $startTime->diffInMinutes($checkTime);
            $data['early_arrival_minutes'] = 0;
            if ($allowedLateMinutes > 0) {
                $data['status'] = ($data['delay_minutes'] <= $allowedLateMinutes) ? Attendance::STATUS_ON_TIME : Attendance::STATUS_LATE_ARRIVAL;
            } else {
                $data['status'] = Attendance::STATUS_LATE_ARRIVAL;
            }
        } else {
            // Employee is early
            $data['delay_minutes'] = 0;
            $data['early_arrival_minutes'] = $checkTime->diffInMinutes($startTime);
            // $data['status'] = ($data['early_arrival_minutes'] == 0) ? Attendance::STATUS_ON_TIME : Attendance::STATUS_EARLY_ARRIVAL;
            $data['status'] = $checkTime->diffInMinutes($nearestPeriod?->start_at) >= Setting::getSetting('early_attendance_minutes') ? Attendance::STATUS_EARLY_ARRIVAL : Attendance::STATUS_ON_TIME;

        }

        if ($nearestPeriod->start_at < $allowedTimeBeforePeriod &&
            $checkTime->toTimeString() > $allowedTimeBeforePeriod &&
            $nearestPeriod->start_at < $checkTime->toTimeString()) {
            $nearestPeriodStart = Carbon::parse($nearestPeriod->start_at)->addDay(); // Add a day to handle the transition to midnight
            $data['check_date'] = Carbon::parse($date)->addDay()->format('Y-m-d');
            $data['day'] = Carbon::parse($date)->addDay()->format('l');
            $data['status'] = $checkTime->diffInMinutes($nearestPeriodStart) >= Setting::getSetting('early_attendance_minutes') ? Attendance::STATUS_EARLY_ARRIVAL : Attendance::STATUS_ON_TIME;
            $data['early_arrival_minutes'] = $checkTime->diffInMinutes($nearestPeriodStart);
            $data['delay_minutes'] = 0;
        }

        return $data;
    }

    /**
     * to store checkout attendance
     */
    private function storeCheckOut($nearestPeriod, $employeeId, $date, $checkTime, $previousCheckInRecord = null)
    {

        $startTime = Carbon::parse($nearestPeriod->start_at);
        $endTime = Carbon::parse($nearestPeriod->end_at);
        // Find the corresponding check-in record
        $checkinRecord = Attendance::where('employee_id', $employeeId)
            ->where('period_id', $nearestPeriod->id)
            ->where('check_type', Attendance::CHECKTYPE_CHECKIN)
            ->whereDate('check_date', $date) // Use the provided check date
            ->latest('id')
            ->first();

        if ($checkinRecord) {

            $checkinTime = Carbon::parse($checkinRecord->check_time);

            // Calculate the actual duration (from check-in to check-out)
            $actualDuration = $checkinTime->diff($checkTime);
            $hoursActual = $actualDuration->h;
            $minutesActual = $actualDuration->i;

            // Store both durations in a format like "hours:minutes"
            $currentDurationFormatted = sprintf('%02d:%02d', $hoursActual, $minutesActual);
            $data['actual_duration_hourly'] = $currentDurationFormatted;
            $data['supposed_duration_hourly'] = $nearestPeriod?->supposed_duration;
            $data['checkinrecord_id'] = $checkinRecord?->id;
            $data['check_date'] = $date;
            $hasCheckoutForDate = $this->checkHasCheckoutInDate($nearestPeriod, $employeeId, $date);
            if ($hasCheckoutForDate) {
                $totalDurationFormatted = $this->totalActualDurationHourly($date, $nearestPeriod, $employeeId);
                $totalDuration = Carbon::createFromFormat('H:i', $totalDurationFormatted);
                $currentDuration = Carbon::createFromFormat('H:i', $currentDurationFormatted);

                // Add the durations
                $sumDuration = $totalDuration->addMinutes($currentDuration->hour * 60 + $currentDuration->minute);

                // Format the result back to H:i format
                $sumDurationFormatted = $sumDuration->format('H:i');
            } else {
                $sumDurationFormatted = $currentDurationFormatted;
            }
        } else if (!$checkinRecord && $previousCheckInRecord) {

            $previousDayName = $previousCheckInRecord['previous_day_name'];
            $previousCheckInRecord = $previousCheckInRecord['in_previous'];

            // Combine the date and time into one string
            $dateTimeString = $previousCheckInRecord->check_date . ' ' . $previousCheckInRecord->check_time;

            $checkinTime = Carbon::createFromFormat('Y-m-d H:i:s', $dateTimeString);

            // Calculate the actual duration (from check-in to check-out)
            $actualDuration = $checkinTime->diff($checkTime);
            $hoursActual = $actualDuration->h;
            $minutesActual = $actualDuration->i;

            $currentDurationFormatted = sprintf('%02d:%02d', $hoursActual, $minutesActual);
            // Store both durations in a format like "hours:minutes"
            $data['actual_duration_hourly'] = $currentDurationFormatted;
            $data['supposed_duration_hourly'] = $nearestPeriod?->supposed_duration;
            $data['checkinrecord_id'] = $previousCheckInRecord?->id;
            $data['check_date'] = $previousCheckInRecord?->check_date;
            $data['day'] = $previousDayName;
            $data['is_from_previous_day'] = 1;

            $hasCheckoutForDate = $this->checkHasCheckoutInDate($nearestPeriod, $employeeId, $previousCheckInRecord?->check_date);
            if ($hasCheckoutForDate) {
                $totalDurationFormatted = $this->totalActualDurationHourly($previousCheckInRecord?->check_date, $nearestPeriod, $employeeId);

                $totalDuration = Carbon::createFromFormat('H:i', $totalDurationFormatted);
                $currentDuration = Carbon::createFromFormat('H:i', $currentDurationFormatted);

                // Add the durations
                $sumDuration = $totalDuration->addMinutes($currentDuration->hour * 60 + $currentDuration->minute);

                // Format the result back to H:i format
                $sumDurationFormatted = $sumDuration->format('H:i');

            } else {

                $sumDurationFormatted = $currentDurationFormatted;
            }

        }

        // Calculate late departure or early departure
        if ($checkTime->gt($endTime)) {
            // Late departure
            $data['late_departure_minutes'] = $endTime->diffInMinutes($checkTime);
            $data['early_departure_minutes'] = 0;
            $data['status'] = Attendance::STATUS_LATE_DEPARTURE;

        } else if ($endTime->gt($checkTime)) {
            // Early departure
            $data['late_departure_minutes'] = 0;
            $data['early_departure_minutes'] = $checkTime->diffInMinutes($endTime);
            $data['status'] = Attendance::STATUS_EARLY_DEPARTURE;
        } else {
            $data['late_departure_minutes'] = 0;
            $data['early_departure_minutes'] = 0;
            $data['status'] = Attendance::STATUS_ON_TIME;

        }
        $data['delay_minutes'] = 0; // Initialize for check-out
        $data['total_actual_duration_hourly'] = $sumDurationFormatted;
        $allowedTimeAfterPeriod = Carbon::createFromFormat('H:i:s', $nearestPeriod->end_at)->addHours((int) Setting::getSetting('hours_count_after_period_after'))->format('H:i:s');

        // dd($nearestPeriod->end_at , $allowedTimeAfterPeriod ,
        //     $checkTime->toTimeString() , $nearestPeriod->end_at ,
        //     $allowedTimeAfterPeriod , $checkTime->toTimeString());
        if ($nearestPeriod->end_at > $allowedTimeAfterPeriod &&
            $checkTime->toTimeString() < $nearestPeriod->end_at &&
            $allowedTimeAfterPeriod > $checkTime->toTimeString()) {

            $nearestPeriodEnd = Carbon::parse($nearestPeriod->end_at)->subDay(); // Add a day to handle the transition to midnight
            //   dd($nearestPeriodEnd,$checkTime);
            // $data['check_date'] = Carbon::parse($date)->addDay()->format('Y-m-d');
            // $data['day'] = Carbon::parse($date)->addDay()->format('l');
            $data['status'] = Attendance::STATUS_LATE_DEPARTURE;
            $data['delay_minutes'] = $nearestPeriodEnd->diffInMinutes($checkTime);
            $data['early_arrival_minutes'] = 0;
            $data['early_departure_minutes'] = 0;
        }

        return $data;
    }

    private function sendAttendanceNotification($employeeName, $message)
    {
        return NotificationAttendance::make()
            ->title(__('notifications.welcome_employee') . ' ' . $employeeName)
            ->body($message)
            ->icon('heroicon-o-check-circle')
            ->iconSize(IconSize::Large)
            ->iconPosition(IconPosition::Before)
            ->duration(10000)
            ->iconColor('success')
            ->success()
            ->send();
    }

    private function sendWarningNotification($message)
    {

        return NotificationAttendance::make()
            ->title(__('notifications.notify'))
            ->body($message)
            ->icon('heroicon-o-exclamation-triangle')
            ->iconSize(IconSize::Large)
            ->iconPosition(IconPosition::Before)
            ->duration(10000)
            ->iconColor('warning')
            ->warning()
            ->send();
    }

    /**
     * to get total actual duration hourly
     */
    private function totalActualDurationHourly($date, $nearestPeriod, $employeeId)
    {

        $previousActualDurationHours = Attendance::where('check_date', $date)
            ->where('check_type', Attendance::CHECKTYPE_CHECKOUT)
            ->where('period_id', $nearestPeriod->id)
            ->where('employee_id', $employeeId)
            ->select('actual_duration_hourly')
            ->get()
            ->pluck('actual_duration_hourly')
            ->toArray();

        $totalMinutes = 0; // Initialize total minutes

// Loop through the duration times and convert each to minutes
        foreach ($previousActualDurationHours as $duration) {
            $time = Carbon::parse($duration);
            $totalMinutes += ($time->hour * 60) + $time->minute; // Convert hours to minutes and add minutes
        }

        $totalHours = intdiv($totalMinutes, 60); // Get the whole number of hours
        $remainingMinutes = $totalMinutes % 60; // Get the remaining minutes

        $totalDurationFormatted = sprintf('%02d:%02d', $totalHours, $remainingMinutes);
        return $totalDurationFormatted;

    }

    /** to check if has chechout for date */
    private function checkHasCheckoutInDate($nearestPeriod, $employeeId, $date)
    {
        return Attendance::where('employee_id', $employeeId)
            ->where('period_id', $nearestPeriod->id)
            ->where('check_type', Attendance::CHECKTYPE_CHECKOUT)
            ->whereDate('check_date', $date)->exists();

    }

    /**
     * check if attendanceInPreviousDay is completed
     */
    private function checkIfattendanceInPreviousDayIsCompleted($attendanceInPreviousDay, $period, $currentCheckTime, $currentDate, $currentDateTrue)
    {
        $previousDate = $attendanceInPreviousDay?->check_date;
        $periodId = $attendanceInPreviousDay?->period_id;
        $employeId = $attendanceInPreviousDay?->employee_id;
        $periodEndTime = $period->end_at;
        $periodStartTime = $period->start_at;

        $allowedTimeAfterPeriod = Carbon::createFromFormat('H:i:s', $periodEndTime)->addHours((int) Setting::getSetting('hours_count_after_period_after'))->format('H:i:s');

        $latstAttendance = Attendance::where('employee_id', $employeId)
            ->where('period_id', $periodId)
            ->where('check_date', $previousDate)
            ->select('id', 'check_type', 'check_date', 'check_time', 'is_from_previous_day')
            ->latest('id')
            ->first()
        ;

        $lastCheckType = $latstAttendance->check_type;

        $dateTimeString = $attendanceInPreviousDay->check_date . ' ' . $latstAttendance->check_time;
        $lastCheckTime = Carbon::createFromFormat('Y-m-d H:i:s', $dateTimeString);

        $dateTimeString = $currentDateTrue . ' ' . $periodEndTime;
        $diff = $this->calculateTimeDifference($periodEndTime, $currentCheckTime, true);
        // dd(Setting::getSetting('hours_count_after_period_after'),$currentCheckTime , $periodEndTime);
        if ($currentCheckTime > $periodEndTime) {
            if ($diff >= Setting::getSetting('hours_count_after_period_after')) {
                return true;
            }
        }

        if ($periodStartTime > $periodEndTime) {

            if ($lastCheckType == Attendance::CHECKTYPE_CHECKOUT) {
                if ($currentCheckTime >= $periodEndTime) {
                    return true;
                }
            } else {
                if ($currentCheckTime >= $periodStartTime) {
                    return true;
                }
            }

        } else {
            // dd($currentCheckTime, $periodEndTime, $allowedTimeAfterPeriod, ($currentCheckTime < $periodEndTime && $currentCheckTime > $allowedTimeAfterPeriod));
            // if ($currentCheckTime < $periodEndTime) {
            if ($currentCheckTime < $periodEndTime && $currentCheckTime > $allowedTimeAfterPeriod) {
                $diff = $this->calculateTimeDifference($periodEndTime, $currentCheckTime, true);
                // dd('hi',$diff,$periodEndTime,$currentCheckTime);
                if ($diff >= Setting::getSetting('hours_count_after_period_after')) {
                    return true;
                }
            }
            if ($lastCheckType == Attendance::CHECKTYPE_CHECKOUT) {
                if ($lastCheckTime >= $periodEndTime) {
                    return true;
                }
            } else {
                if ($currentCheckTime >= $periodStartTime) {
                    return true;
                }
            }
        }
        return false;
    }

    private function checkIfSamePeriod($employeeId, $attendanceInPreviousDay, $period, $date, $currentDate, $checkTime)
    {

        $latstAttendance = Attendance::where('employee_id', $employeeId)
            ->select('id', 'check_type', 'check_date', 'check_time', 'period_id')
            ->latest('id')
            ->first()
        ;

        if ($latstAttendance && $latstAttendance->period_id == $period->id) {
            $isPreviousCompleted = $this->checkIfattendanceInPreviousDayIsCompleted($attendanceInPreviousDay, $period, $checkTime, $date, $currentDate);
            if (!$isPreviousCompleted) {
                return true;
            }
        }
        return false;
    }

    public function calculateTimeDifference(string $currentTime, string $endTime): float
    {
        // Create DateTime objects for each time
        $currentDateTime = new DateTime($currentTime);
        $periodEndDateTime = new DateTime($endTime);

        // Calculate the difference
        $diff = $currentDateTime->diff($periodEndDateTime);

        // Get the total difference in hours
        $totalHours = $diff->h + ($diff->i / 60); // Include minutes as a fraction of an hour

        // If the current time is greater than the end time, calculate total hours accordingly
        if ($currentDateTime > $periodEndDateTime) {
            // Circular manner (i.e., next day)
            $totalHours = (24 - $periodEndDateTime->format('H')) + $currentDateTime->format('H') + (($currentDateTime->format('i') - $periodEndDateTime->format('i')) / 60);
        }

        return round($totalHours, 2); // Round to two decimal places for clarity
    }

}
