<?php
 
namespace App\Filament\Pages;
 
class TestDashboard extends Dashboard
{
    protected static string $routePath = 'test-dashboard';
    protected static ?string $title = 'Finance dashboard';
}