<?php

namespace App\Filament\Clusters\HRAttendanceReport\Resources;

use Filament\Pages\Enums\SubNavigationPosition;
use Filament\Support\Enums\TextSize;
use LaraZeus\InlineChart\Tables\Columns\InlineChart;
use Filament\Actions\Action;
use Filament\Actions\BulkAction;
use App\Filament\Clusters\HRAttendanceReport;
use App\Filament\Clusters\HRAttendanceReport\Resources\EmployeeTaskReportResource\Widgets\TaskWidgetChart;
use App\Filament\Clusters\HRTaskReport;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\Task;
use App\Models\TaskLog;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TextInput;
use Mccarlosen\LaravelMpdf\Facades\LaravelMpdf as PDF;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Support\Colors\Color;
use Filament\Support\Enums\FontWeight;
use Filament\Tables\Actions\HeaderActionsPosition;
use Filament\Tables\Columns\Summarizers\Sum;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Calculation\Statistical\Minimum;

class EmployeeTaskReportResource extends Resource
{
    protected static ?string $model = Task::class;
    protected static ?string $slug = 'employee-task-report';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-rectangle-stack';

    protected static ?string $cluster = HRTaskReport::class;
    protected static ?string $label = 'Employee tasks';

    protected static ?\Filament\Pages\Enums\SubNavigationPosition $subNavigationPosition = SubNavigationPosition::Top;
    protected static ?int $navigationSort = 4;

    public static function table(Table $table): Table
    {

        return $table
            ->paginated([10, 25, 50, 100])
            ->defaultPaginationPageOption(50)
            ->emptyStateHeading('No data')->striped()
            ->columns([
                TextColumn::make('employee_id')->label('Employee id')->searchable(isGlobal: true)->alignCenter(true)
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('employee_no')->label('NO.')->searchable(isGlobal: true)->alignCenter(true)
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('employee_name')->label('Employee name')
                    ->searchable(isGlobal: true)->wrap()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('task_id')
                    ->tooltip(fn($record): string => $record->title . '  Task no #' . $record->id)
                    ->size(TextSize::Small)
                    ->color(Color::Green)
                    ->weight(FontWeight::ExtraBold)
                    // ->description('Click')
                    ->searchable()->icon('heroicon-o-eye')
                    ->label('Task id')->searchable(isGlobal: true)->alignCenter(true)
                    ->toggleable(isToggledHiddenByDefault: true)

                    ->url(fn($record): string => url('admin/h-r-tasks-system/tasks/' . $record->task_id . '/edit'))->openUrlInNewTab(),
                TextColumn::make('task_title')->label('Task title')
                    ->toggleable(isToggledHiddenByDefault: false)
                    ->searchable(isGlobal: true)->wrap(),
                TextColumn::make('task_status')->label('Status')->searchable(isGlobal: true)->alignCenter(true)
                    ->badge()->alignCenter(true)
                    ->icon(fn(string $state): string => match ($state) {
                        Task::STATUS_NEW => Task::ICON_NEW,
                        // Task::STATUS_PENDING =>  Task::ICON_PENDING,
                        Task::STATUS_IN_PROGRESS => Task::ICON_IN_PROGRESS,
                        Task::STATUS_CLOSED => Task::ICON_CLOSED,
                        Task::STATUS_REJECTED => Task::ICON_REJECTED,
                    })
                    ->color(fn(string $state): string => match ($state) {
                        Task::STATUS_NEW => Task::STATUS_NEW,
                        // Task::STATUS_PENDING => Task::COLOR_PENDING,
                        Task::STATUS_IN_PROGRESS => Task::COLOR_IN_PROGRESS,

                        Task::STATUS_CLOSED => Task::COLOR_CLOSED,
                        Task::STATUS_REJECTED => Task::COLOR_REJECTED,
                        // default => 'gray', // Fallback color in case of unknown status
                    })
                    ->toggleable(isToggledHiddenByDefault: false),
                TextColumn::make('total_spent_seconds')

                    ->label('Time spent')->alignCenter(true)->formatStateUsing(function ($state) {
                        if ($state === null) {
                            return '-';
                        }

                        $days = intdiv($state, 86400);
                        $state %= 86400;
                        $hours = intdiv($state, 3600);
                        $state %= 3600;
                        $minutes = intdiv($state, 60);
                        $seconds = $state % 60;

                        // Format as d h m s
                        $formattedTime = '';
                        if ($days > 0) {
                            $formattedTime .= sprintf("%dd ", $days);
                        }
                        if ($hours > 0 || $days > 0) {
                            $formattedTime .= sprintf("%dh ", $hours);
                        }
                        if ($minutes > 0 || $hours > 0 || $days > 0) {
                            $formattedTime .= sprintf("%dm ", $minutes);
                        }
                        $formattedTime .= sprintf("%ds", $seconds);

                        return trim($formattedTime);
                    })->toggleable(isToggledHiddenByDefault: false),
                // InlineChart::make('progress')->label('Progress')
                //     ->chart(TaskWidgetChart::class)


                //     ->maxWidth(80)
                //     ->maxHeight(100)->alignCenter(true)
                //     ->description('')->hidden()
                //     ->toggleable(false),
                TextColumn::make('progress_percentage')->label('Progress')
                    ->getStateUsing(function ($record) {
                        $task = Task::find($record->task_id);
                        return $task->progress_percentage;
                    })->alignCenter(true)->toggleable(false)->suffix('%')
            ])
            ->filters([
                SelectFilter::make('hr_employees.branch_id')->placeholder('Branch')
                    ->label('Branch')
                    ->options(Branch::where('active', 1)
                        ->select('name', 'id')->get()->pluck('name', 'id'))->searchable(),
                SelectFilter::make('hr_employees.id')
                    ->placeholder('Employee')
                    ->label('Employee')
                    ->getSearchResultsUsing(fn(string $search): array => Employee::where('name', 'like', "%{$search}%")->limit(5)->pluck('name', 'id')->toArray())
                    ->getOptionLabelUsing(fn($value): ?string => Employee::find($value)?->name)
                    ->searchable(),
                SelectFilter::make('hr_tasks.id')->placeholder('Task id')
                    ->label('Task id')->searchable()
                    ->getSearchResultsUsing(fn(string $search): array => Task::where('id', 'like', "%{$search}%")->limit(5)->pluck('id', 'id')->toArray())
                    ->getOptionLabelUsing(fn($value): ?string => Task::find($value)?->id),

                Filter::make('created_at')
                    ->schema([
                        DatePicker::make('created_from')
                            ->label('From')->default(null)
                            ->placeholder('From'),
                        DatePicker::make('created_until')
                            ->label('To')
                            ->placeholder('To')->default(null),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['created_from'],
                                fn(Builder $query, $date): Builder => $query->whereDate('hr_tasks.created_at', '>=', $date),
                            )
                            ->when(
                                $data['created_until'],
                                fn(Builder $query, $date): Builder => $query->whereDate('hr_tasks.created_at', '<=', $date),
                            );
                    })
            ], FiltersLayout::AboveContent)
            ->recordActions([
                Action::make('pdf')->label('PDF')
                    ->button()
                    ->action(function ($record) {
                        // Fetch data for the report
                        // $data = static::getEloquentQuery()->get();
                        $task = Task::with('steps')->find($record->task_id);
                        $employee = $task->assigned;
                        $branch = $record->branch;
                        // return view('export.reports.hr.tasks.employee-task-report2', compact('employee','branch','task'));
                        // Generate the PDF using a view
                        $pdf = Pdf::loadView('export.reports.hr.tasks.employee-task-report2', ['task' => $task, 'employee' => $employee, 'branch' => $branch]);

                        return response()->streamDownload(
                            function () use ($pdf) {
                                echo $pdf->output();
                            },
                            $employee->name . ' Task #' . $task->id . '.pdf',
                            [
                                'Content-Type' => 'application/pdf',
                                // 'Content-Disposition' => 'inline; filename="employee_task_report.pdf"',
                                'Charset' => 'UTF-8',
                                'Content-Disposition' => 'inline; filename="' . $employee->name . ' Task #' . $task->id . '.pdf"',
                                'Content-Language' => 'ar',
                                'Accept-Charset' => 'UTF-8',
                                'Content-Encoding' => 'UTF-8',
                                'direction' => 'rtl'
                            ]
                        );
                    }),
            ])
            ->selectable()
            ->headerActions([
                Action::make('printall')->label('Print all')->icon('heroicon-o-printer')
                    ->action(function () {
                        $records = EmployeeTaskReportResource::getEloquentQuery()->get();
                        // Fetch data for the report and add progress percentage
                        $data = $records->map(function ($record) {
                            $task = Task::find($record->task_id);
                            $record->employee_name = $record->employee_name;
                            $record->progress_percentage = ($task ? $task->progress_percentage : 0) . '%';
                            return $record;
                        });

                        // Generate the PDF using a view
                        $pdf = PDF::loadView('export.reports.hr.tasks.employee-task-report-print-all', ['data' => $data]);

                        return response()->streamDownload(
                            function () use ($pdf) {
                                echo $pdf->output();
                            },
                            'employee_tasks_report.pdf',
                            [
                                'Content-Type' => 'application/pdf',
                                'Charset' => 'UTF-8',
                                'Content-Disposition' => 'inline; filename="employee_tasks_report.pdf"',
                                'Content-Language' => 'ar',
                                'Accept-Charset' => 'UTF-8',
                                'Content-Encoding' => 'UTF-8',
                                'direction' => 'rtl'
                            ]
                        );
                    }),
            ], HeaderActionsPosition::Adaptive)
            ->selectCurrentPageOnly()
            ->toolbarActions([
                BulkAction::make('printselected')->label('Print selected')->button()->icon('heroicon-o-printer')

                    // ->accessSelectedRecords()
                    ->deselectRecordsAfterCompletion()

                    ->action(function (Collection $records) {

                        // Fetch data for the report and add progress percentage
                        $data = $records->map(function ($record) {
                            $task = Task::find($record->task_id);
                            $record->employee_name = $record->employee_name;
                            $record->progress_percentage = ($task ? $task->progress_percentage : 0) . '%';
                            return $record;
                        });


                        // Initialize variables for summing and counting
                        $totalProgress = 0;
                        $totalRecords = 0;

                        // Iterate over $data to calculate the sum and count
                        foreach ($data as $record) {

                            $totalProgress += (float) $record->progress_percentage; // Add progress percentage
                            $totalRecords++; // Increment the record count
                        }

                        // Calculate the average progress percentage
                        $averageProgress = $totalRecords > 0 ? $totalProgress / $totalRecords : 0;

                        // Format the average as a percentage
                        $averageProgressFormatted = sprintf("%.2f%%", $averageProgress);



                        $sumSpentTime = $data->sum('total_spent_seconds');

                        // Calculate hours and minutes
                        $hours = intdiv($sumSpentTime, 3600);
                        $sumSpentTime %= 3600;
                        $minutes = intdiv($sumSpentTime, 60);

                        // Format as Hours:Minutes
                        $formattedTime = sprintf("%02d:%02d", $hours, $minutes);

                        $finalSpentTime = $formattedTime;
                        // $finalSpentTime = trim($formattedTime);

                        // Generate the PDF using a view
                        $pdf = PDF::loadView('export.reports.hr.tasks.employee-task-report', [
                            'data' => $data,
                            'final_total_spent_time' => $finalSpentTime,
                            'average_progress' => $averageProgressFormatted,
                        ]);

                        return response()->streamDownload(
                            function () use ($pdf) {
                                echo $pdf->output();
                            },
                            'employee_tasks_report.pdf',
                            [
                                'Content-Type' => 'application/pdf',
                                'Charset' => 'UTF-8',
                                'Content-Disposition' => 'inline; filename="employee_tasks_report.pdf"',
                                'Content-Language' => 'ar',
                                'Accept-Charset' => 'UTF-8',
                                'Content-Encoding' => 'UTF-8',
                                'direction' => 'rtl'
                            ]
                        );
                    })
            ])
        ;
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getPages(): array
    {
        return [
            'index' => ListEmployeeTasksReport::route('/'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        $query = Employee::select(
            'hr_employees.branch_id as branch_id',
            'hr_employees.id as employee_id',
            'hr_employees.employee_no as employee_no',
            'hr_employees.name as employee_name',
            'hr_tasks.id as task_id',
            'hr_tasks.title as task_title',
            'hr_tasks.task_status as task_status',
            DB::raw('SUM(TIME_TO_SEC(hr_task_logs.total_hours_taken)) as total_spent_seconds')

        )->join('hr_tasks', 'hr_employees.id', '=', 'hr_tasks.assigned_to')
            ->leftJoin('hr_task_logs', 'hr_tasks.id', '=', 'hr_task_logs.task_id')
            ->where('hr_task_logs.log_type', TaskLog::TYPE_MOVED)
            ->whereJsonContains('hr_task_logs.details->to', Task::STATUS_CLOSED, '!=');

        $query = $query->groupBy('hr_employees.id', 'hr_tasks.title', 'hr_employees.branch_id', 'hr_employees.employee_no', 'hr_employees.name', 'hr_tasks.id', 'hr_tasks.task_status');

        // dd($query->toSql());
        return $query->orderBy('hr_tasks.id', 'desc');
    }

    public static function canViewAny(): bool
    {
        if (isSuperAdmin() || isSystemManager()) {
            return true;
        }
        return false;
    }
}
