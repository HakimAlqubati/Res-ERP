<?php

namespace App\Filament\Clusters\HRCluster\Resources\MonthlyIncentiveResource\Pages;

use App\Filament\Clusters\HRCluster\Resources\MonthlyIncentiveResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewMonthlyIncentive extends ViewRecord
{
    protected static string $resource = MonthlyIncentiveResource::class;
}
