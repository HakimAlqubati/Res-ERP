<?php

namespace App\Filament\Clusters\HRCluster\Resources\AllowanceResource\Pages;

use App\Filament\Clusters\HRCluster\Resources\AllowanceResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewAllowance extends ViewRecord
{
    protected static string $resource = AllowanceResource::class;
   
}
