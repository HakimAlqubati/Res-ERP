<?php

namespace App\Filament\Clusters\SupplierStoresReportsCluster\Resources\InventoryTransactionReportResource\Pages;

use App\Filament\Traits\HasBackButtonAction;
use App\Filament\Clusters\SupplierStoresReportsCluster\Resources\InventoryTransactionReportResource;
use App\Models\Product;
use App\Services\InventoryService;
use App\Services\MultiProductsInventoryService;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListInventoryTransactionReport extends ListRecords
{
    use HasBackButtonAction;
    protected static string $resource = InventoryTransactionReportResource::class;
    // protected static string $view = 'filament.pages.inventory-reports.inventory-report';
    protected string $view = 'filament.pages.inventory-reports.multi-products-inventory-report';


    public $perPage = 15;

    protected function getViewData(): array
    {
        $productIds = $this->getTable()->getFilters()['product_id']->getState()['values'] ?? [];

        if (!is_array($productIds)) {
            $productIds = [$productIds]; // يحولها لمصفوفة لو كانت قيمة واحدة
        }
        $productId = $productIds[0] ?? null; // احصل على أول منتج من المصفوفة
        $storeId = $this->getTable()->getFilters()['store_id']->getState()['value'];
        $categoryId = $this->getTable()->getFilters()['category_id']->getState()['value'] ?? null;
        $showAvailableInStock = $this->getTable()->getFilters()['show_extra_fields']->getState()['only_available'];
        $unitId = 'all';

        $inventoryService = new MultiProductsInventoryService($categoryId, $productId, $unitId, $storeId, $showAvailableInStock);
        $inventoryService->setProductIds($productIds);

 
        $perPage = $this->perPage;

        if ($perPage === 'all') {
            $perPage = 9999; // أو أي عدد كبير جدًا لضمان عرض الكل
        }
 
        // Get paginated report data
        $report = $inventoryService->getInventoryReportWithPagination($perPage);

        $reportData = $report['reportData'] ?? $report;
        $pagination = $report['pagination'] ?? $report;


        return [
            'reportData' => $reportData,
            'storeId' => $storeId,
            'pagination' => $pagination
        ];
    }
}