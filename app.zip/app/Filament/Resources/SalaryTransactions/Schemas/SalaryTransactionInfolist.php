<?php

namespace App\Filament\Resources\SalaryTransactions\Schemas;

use Filament\Schemas\Schema;

class SalaryTransactionInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
