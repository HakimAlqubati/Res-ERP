<?php

namespace App\Filament\Resources\StockReportResource\Pages;

use App\Filament\Resources\StockReportResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStockReport extends CreateRecord
{
    protected static string $resource = StockReportResource::class;
}
