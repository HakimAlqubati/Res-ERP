<?php

namespace App\Filament\Clusters\SupplierStoresReportsCluster\Resources\StockIssueOrderResource\Pages;

use Filament\Actions\CreateAction;
use App\Filament\Clusters\SupplierStoresReportsCluster\Resources\StockIssueOrderResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListStockIssueOrders extends ListRecords
{
    protected static string $resource = StockIssueOrderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
