<?php

namespace App\Filament\Clusters\HRTasksSystem\Resources\TaskResource\RelationManagers;

use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Notifications\Notification;
use Exception;
use Filament\Actions\CreateAction;
use Filament\Actions\EditAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use App\Models\Task;
use App\Models\TaskLog;
use Filament\Forms;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StepsRelationManager extends RelationManager
{
    protected static string $relationship = 'steps';
    public static function getBadge(Model $ownerRecord, string $pageClass): ?string
    {return $ownerRecord->steps->count();}
    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('order')
                    ->required()
                    ->maxLength(255),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table->striped()
            ->recordTitleAttribute('order')
            ->columns([
                TextColumn::make('order')->sortable(),
                TextColumn::make('title')->searchable(),
                
                IconColumn::make('done')
                    ->boolean() // Converts values to boolean, showing one icon for true, another for false
                    ->trueIcon('heroicon-o-check-circle') // Icon when true
                    ->falseIcon('heroicon-o-x-circle') // Icon when false
                    ->action(function ($record) {
                        // Use a database transaction for safe execution
                        DB::beginTransaction();

                        try {
                            // Check the conditions before updating the status
                            if (($record->morphable->task_status == Task::STATUS_NEW || $record->morphable->task_status == Task::STATUS_IN_PROGRESS)
                                && $record->morphable->assigned_to == auth()->user()?->employee?->id) {

                                $currentStatus = $record->morphable->task_status;
                                $nextStatus = Task::STATUS_IN_PROGRESS;

                                // Update task status
                                $record->morphable->update(['task_status' => $nextStatus]);

                                // Log the status change
                                $record->morphable->createLog(
                                    createdBy: auth()->id(), // ID of the user performing the action
                                    description: "Task moved to {$nextStatus}", // Log description
                                    logType: TaskLog::TYPE_MOVED, // Log type as "moved"
                                    details: [
                                        'from' => $currentStatus, // Previous status
                                        'to' => $nextStatus, // New status
                                    ]
                                );
                            }

                            // Toggle the 'done' status
                            $record->update(['done' => $record->done == 1 ? 0 : 1]);

                            // Commit the transaction
                            DB::commit();

                            // Return success message
                            Notification::make()
                                ->title('Success')
                                ->body($record->done ==1 ?'Done': 'Undone')
                                ->success()
                                ->send();

                        } catch (Exception $e) {
                            // Rollback the transaction in case of an error
                            DB::rollBack();

                            // Log the error for debugging
                            Log::error("Error updating task status: " . $e->getMessage());

                            // Return error message
                            Notification::make()
                                ->title('Error')
                                ->body('Failed. Please try again later.')
                                ->danger()
                                ->send();
                        }
                    }),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                CreateAction::make(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    protected function canDeleteAny(): bool
    {
        return false;
    }
    protected function canDelete(Model $record): bool
    {
        return false;
    }
    protected function canEdit(Model $record): bool
    {
        return false;
    }
    protected function canCreate(): bool
    {
        return false;
    }
}
