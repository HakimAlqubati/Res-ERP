<?php

namespace App\Filament\Clusters\HRAttendanceReport\Resources\EmployeeRatingReportResource\Pages;

use App\Filament\Clusters\HRAttendanceReport\Resources\EmployeeRatingReportResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewReportDetail extends ViewRecord
{
    protected static string $resource = EmployeeRatingReportResource::class;
}
